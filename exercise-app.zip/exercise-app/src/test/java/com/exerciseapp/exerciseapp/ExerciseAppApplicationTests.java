package com.exerciseapp.exerciseapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExerciseAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
